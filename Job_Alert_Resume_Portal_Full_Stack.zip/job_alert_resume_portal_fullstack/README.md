# Job Alert and Resume Portal — Full Stack

## Easiest way to run on Windows
1. Install **Node.js LTS** from https://nodejs.org/ (if it is not already installed).
2. Extract this ZIP file.
3. Open the extracted folder.
4. Double-click **START_HERE.bat**. It installs the packages the first time and starts the website.
5. Keep the black terminal window open. The portal opens at **http://localhost:3000**.

**Important:** Do not double-click `public/index.html` and do not use VS Code Live Server. The frontend must be served by the Node.js backend, otherwise login/signup can show `Failed to fetch`.

## Run manually in VS Code
Open a terminal in the folder that contains `package.json`, then run:
```bash
npm install
npm start
```
Then visit http://localhost:3000.

## Demo accounts
**Student**
- Email: `student@demo.com`
- Password: `Student@123`

**Admin**
- Email: `admin@demo.com`
- Password: `Admin@123`

## Technologies
- Frontend: HTML, CSS, JavaScript
- Backend: Node.js + Express REST API
- Database: SQLite (`portal.db`, created automatically)
- Authentication: Express sessions + bcrypt password hashing
- Resume uploads: Multer (PDF, DOC, DOCX; 5 MB limit)

## Features
- Login and sign-up
- Student dashboard and job listings
- Apply for jobs and save/unsave jobs
- Profile management
- Job alerts (create, pause, activate, delete)
- Resume upload, download and delete
- Admin-only job creation/deletion and portal statistics
- Persistent SQLite database

## Files created when running
- `portal.db`: local SQLite database
- `uploads/`: uploaded resumes
- `node_modules/`: installed dependencies

This is a local demonstration project. Before public deployment, configure a strong session secret, HTTPS, secure cookies, rate limiting, and private resume storage. Do not use demo passwords for real accounts.
