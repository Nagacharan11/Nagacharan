@echo off
setlocal
cd /d "%~dp0"
title Job Alert and Resume Portal

echo ==============================================
echo       JOB ALERT AND RESUME PORTAL
echo ==============================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed.
  echo Install Node.js LTS, restart your computer, and run this file again.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Reinstall Node.js LTS.
  pause
  exit /b 1
)

echo Node version:
node -v
if not exist node_modules (
  echo.
  echo Installing project packages. Please wait...
  call npm install
  if errorlevel 1 (
    echo.
    echo INSTALLATION FAILED. Check your internet connection.
    echo Send a screenshot of this window if the error continues.
    pause
    exit /b 1
  )
)
echo.
echo Starting backend server now...
echo WAIT until you see: Job Portal running at http://localhost:3000
echo THEN open your browser and visit http://localhost:3000
echo Keep this window open. Do not open index.html directly.
echo.
call npm start

echo.
echo The server has stopped. Read the error above.
pause
