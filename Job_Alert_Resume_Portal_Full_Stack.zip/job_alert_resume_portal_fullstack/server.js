const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database('portal.db');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student', phone TEXT DEFAULT '',
 education TEXT DEFAULT '', skills TEXT DEFAULT '', location TEXT DEFAULT '', about TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS jobs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, company TEXT NOT NULL,
 location TEXT NOT NULL, type TEXT NOT NULL, salary TEXT, description TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, job_id INTEGER NOT NULL,
 status TEXT DEFAULT 'Submitted', created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id,job_id),
 FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(job_id) REFERENCES jobs(id)
);
CREATE TABLE IF NOT EXISTS saved_jobs (
 user_id INTEGER NOT NULL, job_id INTEGER NOT NULL, PRIMARY KEY(user_id,job_id)
);
CREATE TABLE IF NOT EXISTS alerts (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL,
 keyword TEXT NOT NULL, location TEXT DEFAULT '', active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS resumes (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, original_name TEXT NOT NULL,
 stored_name TEXT NOT NULL, size INTEGER NOT NULL, uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);
const count = db.prepare('SELECT COUNT(*) n FROM jobs').get().n;
if (!count) {
 const insert = db.prepare('INSERT INTO jobs(title,company,location,type,salary,description) VALUES(?,?,?,?,?,?)');
 [
 ['Frontend Developer Intern','BrightByte Technologies','Hyderabad','Internship','₹15,000 / month','Work with HTML, CSS, JavaScript and responsive UI components.'],
 ['Junior React Developer','PixelCraft Solutions','Remote','Full-time','₹4-6 LPA','Build web interfaces using React, JavaScript, HTML, CSS and APIs.'],
 ['Data Analyst Trainee','InsightWorks','Secunderabad','Internship','₹12,000 / month','Assist with data cleaning, Excel reports and dashboards.'],
 ['Node.js Backend Developer','CloudNest Labs','Hyderabad','Full-time','₹5-7 LPA','Develop REST APIs using Node.js and Express.']
 ].forEach(x=>insert.run(...x));
}
const demoHash = bcrypt.hashSync('Student@123', 10);
db.prepare(`INSERT OR IGNORE INTO users(name,email,password,role) VALUES(?,?,?,'student')`)
 .run('Demo Student','student@demo.com',demoHash);
db.prepare(`INSERT OR IGNORE INTO users(name,email,password,role) VALUES(?,?,?,'admin')`)
 .run('Portal Admin','admin@demo.com',bcrypt.hashSync('Admin@123',10));

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret: process.env.SESSION_SECRET || 'change-this-secret-before-deployment',
 resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:'lax',secure:false,maxAge:24*60*60*1000}
}));
app.use(express.static(path.join(__dirname,'public')));
const uploadsDir=path.join(__dirname,'uploads');
if(!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir);
const storage=multer.diskStorage({
 destination:(req,file,cb)=>cb(null,uploadsDir),
 filename:(req,file,cb)=>cb(null,Date.now()+'-'+Math.random().toString(16).slice(2)+path.extname(file.originalname))
});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>{
 const ext=path.extname(file.originalname).toLowerCase();
 cb(null,['.pdf','.doc','.docx'].includes(ext));
}});
const auth=(req,res,next)=>req.session.user?next():res.status(401).json({error:'Please sign in first.'});
const admin=(req,res,next)=>req.session.user?.role==='admin'?next():res.status(403).json({error:'Admin access required.'});
const publicUser=u=>({id:u.id,name:u.name,email:u.email,role:u.role});
app.post('/api/auth/signup',(req,res)=>{
 const {name,email,password}=req.body;
 if(!name||!email||!password||password.length<6) return res.status(400).json({error:'Enter name, valid email and password (at least 6 characters).'});
 try{
  const info=db.prepare('INSERT INTO users(name,email,password) VALUES(?,?,?)').run(name.trim(),email.toLowerCase().trim(),bcrypt.hashSync(password,10));
  const u=db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid);
  req.session.user=publicUser(u); res.json({user:req.session.user});
 }catch(e){res.status(409).json({error:'An account with this email already exists.'});}
});
app.post('/api/auth/login',(req,res)=>{
 const u=db.prepare('SELECT * FROM users WHERE email=?').get(String(req.body.email||'').toLowerCase().trim());
 if(!u||!bcrypt.compareSync(req.body.password||'',u.password)) return res.status(401).json({error:'Incorrect email or password.'});
 req.session.user=publicUser(u);res.json({user:req.session.user});
});
app.post('/api/auth/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/auth/me',(req,res)=>res.json({user:req.session.user||null}));
app.get('/api/jobs',auth,(req,res)=>res.json(db.prepare('SELECT * FROM jobs ORDER BY id DESC').all()));
app.post('/api/jobs',auth,admin,(req,res)=>{
 const {title,company,location,type,salary,description}=req.body;
 if(!title||!company||!location||!description)return res.status(400).json({error:'Please complete all required job fields.'});
 const r=db.prepare('INSERT INTO jobs(title,company,location,type,salary,description) VALUES(?,?,?,?,?,?)').run(title,company,location,type,salary||'',description);
 res.json({id:r.lastInsertRowid});
});
app.delete('/api/jobs/:id',auth,admin,(req,res)=>{
 db.prepare('DELETE FROM jobs WHERE id=?').run(req.params.id);
 db.prepare('DELETE FROM applications WHERE job_id=?').run(req.params.id);
 db.prepare('DELETE FROM saved_jobs WHERE job_id=?').run(req.params.id);res.json({ok:true});
});
app.post('/api/jobs/:id/apply',auth,(req,res)=>{
 try{db.prepare('INSERT INTO applications(user_id,job_id) VALUES(?,?)').run(req.session.user.id,req.params.id);res.json({ok:true});}
 catch(e){res.status(409).json({error:'You have already applied for this job.'});}
});
app.post('/api/jobs/:id/save',auth,(req,res)=>{
 const uid=req.session.user.id,id=Number(req.params.id);
 const exists=db.prepare('SELECT 1 FROM saved_jobs WHERE user_id=? AND job_id=?').get(uid,id);
 if(exists)db.prepare('DELETE FROM saved_jobs WHERE user_id=? AND job_id=?').run(uid,id);
 else db.prepare('INSERT INTO saved_jobs(user_id,job_id) VALUES(?,?)').run(uid,id);
 res.json({saved:!exists});
});
app.get('/api/dashboard',auth,(req,res)=>{
 const uid=req.session.user.id;
 res.json({
  applications:db.prepare('SELECT a.*,j.title,j.company FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.user_id=? ORDER BY a.id DESC').all(uid),
  saved:db.prepare('SELECT job_id FROM saved_jobs WHERE user_id=?').all(uid).map(x=>x.job_id),
  alerts:db.prepare('SELECT * FROM alerts WHERE user_id=? ORDER BY id DESC').all(uid),
  resumeCount:db.prepare('SELECT COUNT(*) n FROM resumes WHERE user_id=?').get(uid).n,
  jobCount:db.prepare('SELECT COUNT(*) n FROM jobs').get().n
 });
});
app.get('/api/profile',auth,(req,res)=>{
 const u=db.prepare('SELECT name,email,phone,education,skills,location,about FROM users WHERE id=?').get(req.session.user.id);res.json(u);
});
app.put('/api/profile',auth,(req,res)=>{
 const p=req.body;db.prepare('UPDATE users SET name=?,email=?,phone=?,education=?,skills=?,location=?,about=? WHERE id=?')
 .run(p.name,p.email,p.phone||'',p.education||'',p.skills||'',p.location||'',p.about||'',req.session.user.id);
 req.session.user.name=p.name;req.session.user.email=p.email;res.json({ok:true});
});
app.get('/api/alerts',auth,(req,res)=>res.json(db.prepare('SELECT * FROM alerts WHERE user_id=? ORDER BY id DESC').all(req.session.user.id)));
app.post('/api/alerts',auth,(req,res)=>{
 const {name,keyword,location}=req.body;if(!name||!keyword)return res.status(400).json({error:'Enter alert name and keyword.'});
 db.prepare('INSERT INTO alerts(user_id,name,keyword,location) VALUES(?,?,?,?)').run(req.session.user.id,name,keyword,location||'');res.json({ok:true});
});
app.patch('/api/alerts/:id',auth,(req,res)=>{
 db.prepare('UPDATE alerts SET active=1-active WHERE id=? AND user_id=?').run(req.params.id,req.session.user.id);res.json({ok:true});
});
app.delete('/api/alerts/:id',auth,(req,res)=>{db.prepare('DELETE FROM alerts WHERE id=? AND user_id=?').run(req.params.id,req.session.user.id);res.json({ok:true});});
app.post('/api/resumes',auth,(req,res,next)=>upload.single('resume')(req,res,e=>e?res.status(400).json({error:e.message}):next()),(req,res)=>{
 if(!req.file)return res.status(400).json({error:'Choose a PDF, DOC or DOCX file.'});
 db.prepare('INSERT INTO resumes(user_id,original_name,stored_name,size) VALUES(?,?,?,?)').run(req.session.user.id,req.file.originalname,req.file.filename,req.file.size);res.json({ok:true});
});
app.get('/api/resumes',auth,(req,res)=>res.json(db.prepare('SELECT id,original_name,size,uploaded_at FROM resumes WHERE user_id=? ORDER BY id DESC').all(req.session.user.id)));
app.get('/api/resumes/:id/download',auth,(req,res)=>{
 const r=db.prepare('SELECT * FROM resumes WHERE id=? AND user_id=?').get(req.params.id,req.session.user.id);
 if(!r)return res.sendStatus(404);res.download(path.join(uploadsDir,r.stored_name),r.original_name);
});
app.delete('/api/resumes/:id',auth,(req,res)=>{
 const r=db.prepare('SELECT * FROM resumes WHERE id=? AND user_id=?').get(req.params.id,req.session.user.id);
 if(r){try{fs.unlinkSync(path.join(uploadsDir,r.stored_name));}catch{}db.prepare('DELETE FROM resumes WHERE id=?').run(r.id);}res.json({ok:true});
});
app.get('/api/admin/stats',auth,admin,(req,res)=>res.json({
 users:db.prepare('SELECT COUNT(*) n FROM users').get().n,
 jobs:db.prepare('SELECT COUNT(*) n FROM jobs').get().n,
 applications:db.prepare('SELECT COUNT(*) n FROM applications').get().n
}));
app.listen(PORT,()=>console.log(`Job Portal running at http://localhost:${PORT}`));
